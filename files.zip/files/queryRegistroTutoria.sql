SELECT * FROM basedatos.registro_tutoria;
select * from registro_tutoria order by tema DESC;
select * from registro_tutoria limit 5;
select * from registro_tutoria where tema like 'a%';
select * from registro_tutoria where tema like '%a';
select count(*) from registro_tutoria;
select count(*) from registro_tutoria ;