SELECT * FROM usuario;
SELECT id,nombre FROM usuario;
SELECT id,nombre FROM usuario WHERE id_rol=1;
select id_rol,count(*) from usuario group by id_rol;